SELECT mn.MachineName, na.State, na.FirstConnectionUTC, na.LastConnectionUTC, pp.path, pn.Filename, sfn.Filename, na.NonRoutable, na.Port, dom.Domain, na.IP, la.LaunchArguments ,na.UserAgent
--SELECT na.ip,count(*) as cnt
--SELECT pn.FileName,count (*) as cnt
--SELECT na.UserAgent, count(*) as cnt
FROM
	[dbo].[mocNetAddresses] AS [na] WITH(NOLOCK)

		INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [na].[FK_MachineModulePaths])
		INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
		INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [na].[FK_Machines]
		INNER JOIN [dbo].[Filenames] AS [pn] WITH(NOLOCK) ON ([pn].[PK_FileNames] = [na].[FK_FileNames__Process])
		INNER JOIN [dbo].[Domains] AS [dom]  WITH(NOLOCK) ON ([dom].[PK_Domains] = [na].[FK_Domains__DomainHost])
		INNER JOIN [dbo].[LaunchArguments] AS [la] WITH(NOLOCK) ON [la].[PK_LaunchArguments] = [na].[FK_LaunchArguments]
		INNER JOIN [dbo].[Paths] AS [pp] WITH(NOLOCK) ON [pp].[PK_Paths] = [na].[FK_Paths__Process]
		
WHERE
	na.port = 3389
	AND na.state !=2
	AND pn.FileName NOT IN ('mstsc.exe','lnsscomm.exe','RDCMan.exe','TerminalServicesClient.exe','MobaRTE.exe')
	AND pp.Path not like 'C:\Program Files%'
	AND NOT (
				pp.Path = 'C:\windows\system32\' AND
				(pn.FileName IN ('ntoskrnl.exe','svchost.exe'))
			)

--GROUP BY na.ip
order by na.FirstConnectionUTC desc
