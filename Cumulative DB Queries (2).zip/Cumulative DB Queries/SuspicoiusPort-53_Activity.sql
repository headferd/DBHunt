SELECT mn.MachineName, na.State, na.FirstConnectionUTC, na.LastConnectionUTC, pp.path, pn.Filename, sfn.Filename, na.NonRoutable, na.Port, dom.Domain, na.IP, la.LaunchArguments ,na.UserAgent
--SELECT na.ip,count(*) as cnt
--SELECT pn.FileName,count (*) as cnt
--SELECT na.UserAgent, count(*) as cnt
FROM
	[dbo].[mocNetAddresses] AS [na] WITH(NOLOCK)

		INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [na].[FK_MachineModulePaths])
		INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
		INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [na].[FK_Machines]
		INNER JOIN [dbo].[Filenames] AS [pn] WITH(NOLOCK) ON ([pn].[PK_FileNames] = [na].[FK_FileNames__Process])
		INNER JOIN [dbo].[Domains] AS [dom]  WITH(NOLOCK) ON ([dom].[PK_Domains] = [na].[FK_Domains__DomainHost])
		INNER JOIN [dbo].[LaunchArguments] AS [la] WITH(NOLOCK) ON [la].[PK_LaunchArguments] = [na].[FK_LaunchArguments]
		INNER JOIN [dbo].[Paths] AS [pp] WITH(NOLOCK) ON [pp].[PK_Paths] = [na].[FK_Paths__Process]
		
WHERE
	na.NonRoutable = 0 
	AND na.port = 53
	AND sfn.FileName NOT LIKE 'dnsapi.dll'
	AND na.ip NOT LIKE '8.8.%'
	AND na.ip NOT LIKE '75.75.7_.7_'
	AND na.ip NOT LIKE '209.18.47.6_'
	AND na.ip NOT LIKE '108.59.49.19'
	AND na.ip NOT LIKE '208.67.222.222'
	AND na.ip NOT LIKE '169.254.%'
	AND dom.domain NOT LIKE '%.360safe.com'
	AND dom.domain NOT LIKE '%.in.us'
	AND dom.domain NOT LIKE '%in.gov'
	AND la.LaunchArguments NOT LIKE '/start'
	AND la.LaunchArguments NOT LIKE ' -k Net%'
	AND la.LaunchArguments NOT LIKE ' -k Local%'
	AND la.LaunchArguments NOT LIKE '' 

--GROUP BY na.ip
order by na.FirstConnectionUTC desc
