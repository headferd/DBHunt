--===== RSA_IR-New-Rare_TaskengLaunchesPowershell ========--

--/* DB QUERY 

SELECT  mn.MachineName, se.EventUTCTime, sfn.Filename, se.FileName_Target, se.Path_Target, se.LaunchArguments_Target, sla.LaunchArguments

FROM
	[dbo].[WinTrackingEvents_P0] AS [se] WITH(NOLOCK)
	--[dbo].[WinTrackingEvents_P1] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
	INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [se].[FK_Machines]
	INNER JOIN [dbo].[LaunchArguments] AS [sla] WITH(NOLOCK) ON [sla].[PK_LaunchArguments] = [se].[FK_LaunchArguments__SourceCommandLine]

WHERE 

	[se].[BehaviorProcessCreateProcess] = 1
	AND [sfn].FileName = 'taskeng.exe'
	AND se.FileName_Target = 'powershell.exe'
	AND se.LaunchArguments_Target NOT LIKE '%\Program Files%'
	AND se.LaunchArguments_Target NOT LIKE '%\Batch%'
	AND se.LaunchArguments_Target NOT LIKE '%Boottime.ps1"'
	AND se.LaunchArguments_Target NOT LIKE '%\PSAppDeployTool%'
	AND se.LaunchArguments_Target NOT LIKE '%\script%'
	AND se.LaunchArguments_Target NOT LIKE '%warmupserver%'
	AND se.LaunchArguments_Target NOT LIKE '%AgentRestarts.ps1%'
	AND se.LaunchArguments_Target NOT LIKE '%"& _C:\Progra%'
	AND se.LaunchArguments_Target NOT LIKE '%startEMNComDeployment%'
	AND se.LaunchArguments_Target NOT LIKE '%GetvDesktops.ps1%'
	AND se.LaunchArguments_Target NOT LIKE '%StopJob1.ps1%'
	AND se.LaunchArguments_Target NOT LIKE '%\rmgnetworks\%'
	AND se.LaunchArguments_Target NOT LIKE '%\IT_Folder\%'
	AND se.LaunchArguments_Target NOT LIKE '%\Projects\%'
	AND se.LaunchArguments_Target NOT LIKE '%c:\PKI\%'
	AND se.LaunchArguments_Target NOT LIKE '%jobDef =%'
	
	ORDER BY [se].[LaunchArguments_Target]
	

--*/


/* IIOC QUERY
SELECT DISTINCT
	[mp].[FK_Machines] AS [FK_Machines],
	[mp].[PK_MachineModulePaths] AS [FK_MachineModulePaths]

FROM
	[dbo].[WinTrackingEventsCache] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
	
WHERE 
	[se].[BehaviorProcessCreateProcess] = 1
	AND [sfn].FileName = 'taskeng.exe'
	AND se.FileName_Target = 'powershell.exe'
	AND se.LaunchArguments_Target NOT LIKE '%\Program Files%'
	AND se.LaunchArguments_Target NOT LIKE '%\Batch%'
	AND se.LaunchArguments_Target NOT LIKE '%Boottime.ps1"'
	AND se.LaunchArguments_Target NOT LIKE '%\PSAppDeployTool%'
	AND se.LaunchArguments_Target NOT LIKE '%\script%'
	AND se.LaunchArguments_Target NOT LIKE '%warmupserver%'
	AND se.LaunchArguments_Target NOT LIKE '%AgentRestarts.ps1%'
	AND se.LaunchArguments_Target NOT LIKE '%"& _C:\Progra%'
	AND se.LaunchArguments_Target NOT LIKE '%startEMNComDeployment%'
	AND se.LaunchArguments_Target NOT LIKE '%GetvDesktops.ps1%'
	AND se.LaunchArguments_Target NOT LIKE '%StopJob1.ps1%'
	AND se.LaunchArguments_Target NOT LIKE '%\rmgnetworks\%'
	AND se.LaunchArguments_Target NOT LIKE '%\IT_Folder\%'
	AND se.LaunchArguments_Target NOT LIKE '%\Projects\%'
	AND se.LaunchArguments_Target NOT LIKE '%c:\PKI\%'
	AND se.LaunchArguments_Target NOT LIKE '%jobDef =%'
*/