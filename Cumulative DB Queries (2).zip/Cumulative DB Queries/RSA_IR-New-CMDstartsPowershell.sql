SELECT  mn.MachineName, se.EventUTCTime, sfn.Filename, se.FileName_Target, se.Path_Target, se.LaunchArguments_Target, sla.LaunchArguments

FROM
	[dbo].[WinTrackingEvents_P0] AS [se] WITH(NOLOCK)
	--[dbo].[WinTrackingEvents_P1] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
	INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [se].[FK_Machines]
	INNER JOIN [dbo].[LaunchArguments] AS [sla] WITH(NOLOCK) ON [sla].[PK_LaunchArguments] = [se].[FK_LaunchArguments__SourceCommandLine]

WHERE 
	[se].[BehaviorProcessCreateProcess] = 1
	AND [sfn].FileName = 'cmd.exe'
	AND se.FileName_Target = 'powershell.exe'
	AND NOT se.LaunchArguments_Target LIKE '%\shared\%'
	AND NOT se.LaunchArguments_Target LIKE 'powershell'
	AND NOT se.LaunchArguments_Target LIKE '%.in.gov%'
	AND NOT se.LaunchArguments_Target LIKE '%.in.us%'
	AND NOT se.LaunchArguments_Target LIKE '%\Program Files%'
	AND NOT se.LaunchArguments_Target LIKE '%\vmware-system%'
	AND NOT se.LaunchArguments_Target LIKE '%\rvplayer\%'
	AND NOT se.LaunchArguments_Target LIKE '%\Oracle\Operations%'
	AND NOT se.LaunchArguments_Target LIKE '%badge_activate.ps1'
	AND NOT se.LaunchArguments_Target LIKE '%Error Handling Wrapper%'
	AND NOT se.LaunchArguments_Target LIKE '%[D-Z]:\%'
	AND NOT se.LaunchArguments_Target LIKE '%\scriptstest\%'
	AND NOT se.LaunchArguments_Target LIKE '%Windows Defender%'
	AND NOT se.LaunchArguments_Target LIKE '%ccmcache%'
	
	ORDER BY se.EventUTCTime DESC