--===== RSA_IR-New-UncommonRundll32createsExecutable ========--

SELECT DISTINCT
	[smp].[FK_Machines] AS [FK_Machines],
	[smp].[PK_MachineModulePaths] AS [FK_MachineModulePaths],
	[sse].[RowSipHash] AS [FK_mocSentinelEvents]
FROM
	[dbo].[WinTrackingEventsCache] AS [sse] WITH(NOLOCK) 
	INNER JOIN [dbo].[MachineModulePaths] AS [smp] WITH(NOLOCK) ON ([smp].[PK_MachineModulePaths] = [sse].[FK_MachineModulePaths])
	INNER JOIN [dbo].[Modules] AS [mo] WITH(NOLOCK) ON ([mo].[PK_Modules] = [smp].[FK_Modules])
	INNER JOIN [dbo].[WinTrackingEventsCache] AS [tse] WITH(NOLOCK) ON ([tse].[HashSHA256_Target] = [mo].[HashSHA256] AND [tse].[FK_Machines] = [smp].[FK_Machines])
	INNER JOIN [dbo].[MachineModulePaths] AS [tmp] WITH(NOLOCK) ON ([tmp].[PK_MachineModulePaths] = [tse].[FK_MachineModulePaths])
	INNER JOIN [dbo].[FileNames] AS [tfn] WITH(NOLOCK) ON ([tfn].[PK_FileNames] = [tmp].[FK_FileNames])
	INNER JOIN [dbo].[LaunchArguments] AS [sla] WITH(NOLOCK) ON [sla].[PK_LaunchArguments] = [sse].[FK_LaunchArguments__SourceCommandLine]

WHERE
	[smp].[FK_Modules] != -1 AND
	[tse].[BehaviorFileWriteExecutable] = 1 
	AND tfn.FileName = 'rundll32.exe'
	AND NOT (len(sse.Path_Target) = 53 AND sse.Path_Target LIKE 'c:\windows\temp\%')
	AND NOT (len(sse.Path_Target) = 59 AND sse.Path_Target LIKE 'c:\windows\temp\%')
	AND NOT (len(sse.Path_Target) = 55 AND sse.Path_Target LIKE 'c:\windows\temp\%')
	AND sse.FileName_Target NOT LIKE 'SET%.tmp'
	AND sse.FileName_Target NOT LIKE 'OLD____.tmp'
	AND sse.FileName_Target NOT LIKE '%.%.com'
	AND sla.LaunchArguments NOT LIKE '%zzzzInvokeManagedCustomActionOutofProc%'
	AND sla.LaunchArguments NOT LIKE 'rundll32.exe acmigration.dll,ApplyMigrationShims'
	AND sla.LaunchArguments NOT LIKE '%coin99%.dll,RunSoftwareInstall'
	AND sla.LaunchArguments NOT LIKE '%\Program Files%'
	AND sla.LaunchArguments NOT LIKE '%\drivers\%'
	AND sla.LaunchArguments NOT LIKE '%\FireEye\\%'
	AND sse.Path_Target NOT LIKE '%#%'
	AND sse.FileName_Target NOT LIKE '%[_]%'
	AND [smp].[MarkedAsDeleted] = 0 -- Testing MarkedAsDeleted on MP instead of SE for Events
OPTION (RECOMPILE);


	
	
	