--===== RSA_IR-New-Rare_MSHTA.EXE_Activity ========--

--/* DB QUERY 

SELECT  mn.MachineName, se.EventUTCTime, sfn.Filename, se.FileName_Target, se.Path_Target, se.LaunchArguments_Target, sla.LaunchArguments

FROM
	[dbo].[WinTrackingEvents_P0] AS [se] WITH(NOLOCK)
	--[dbo].[WinTrackingEvents_P1] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
	INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [se].[FK_Machines]
	INNER JOIN [dbo].[LaunchArguments] AS [sla] WITH(NOLOCK) ON [sla].[PK_LaunchArguments] = [se].[FK_LaunchArguments__SourceCommandLine]

WHERE 
	[se].[BehaviorProcessCreateProcess] = 1
	AND sfn.FileName = 'mshta.exe' 
	--se.FileName_Target = 'mshta.exe'
	AND se.LaunchArguments_Target NOT LIKE '%Program Files%HP%'
	AND se.LaunchArguments_Target NOT LIKE '%c:\scripts\%'
	AND se.LaunchArguments_Target NOT LIKE '%ProgramData%HP%'
	AND se.LaunchArguments_Target NOT LIKE '%printui.dll,printuientry%'
	AND se.Path_Target NOT LIKE '%Program Files%HP%'
	AND se.FileName_Target NOT IN ('saplogon.exe','dotnetfx35.exe','dxsetup.exe','msiexec.exe','silverlight.configuration.exe')
	
	ORDER BY [se].[LaunchArguments_Target]
	

--*/


/* IIOC QUERY
SELECT DISTINCT
	[mp].[FK_Machines] AS [FK_Machines],
	[mp].[PK_MachineModulePaths] AS [FK_MachineModulePaths]

FROM
	[dbo].[WinTrackingEventsCache] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
	
WHERE 
	[se].[BehaviorProcessCreateProcess] = 1
	AND sfn.FileName = 'mshta.exe' 
	AND se.LaunchArguments_Target NOT LIKE '%Program Files%HP%'
	AND se.LaunchArguments_Target NOT LIKE '%c:\scripts\%'
	AND se.LaunchArguments_Target NOT LIKE '%ProgramData%HP%'
	AND se.LaunchArguments_Target NOT LIKE '%printui.dll,printuientry%'
	AND se.Path_Target NOT LIKE '%Program Files%HP%'
	AND se.FileName_Target NOT IN ('saplogon.exe','dotnetfx35.exe','dxsetup.exe','msiexec.exe','silverlight.configuration.exe')
*/