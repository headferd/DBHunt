SELECT mn.MachineName, na.FirstConnectionUTC, na.LastConnectionUTC, pp.path, pn.Filename, sfn.Filename, na.NonRoutable, na.Port, dom.Domain, na.IP, la.LaunchArguments ,na.UserAgent

FROM
	[dbo].[mocNetAddresses] AS [na] WITH(NOLOCK)

		INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [na].[FK_MachineModulePaths])
		INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
		INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [na].[FK_Machines]
		INNER JOIN [dbo].[Filenames] AS [pn] WITH(NOLOCK) ON ([pn].[PK_FileNames] = [na].[FK_FileNames__Process])
		INNER JOIN [dbo].[Domains] AS [dom]  WITH(NOLOCK) ON ([dom].[PK_Domains] = [na].[FK_Domains__DomainHost])
		INNER JOIN [dbo].[LaunchArguments] AS [la] WITH(NOLOCK) ON [la].[PK_LaunchArguments] = [na].[FK_LaunchArguments]
		INNER JOIN [dbo].[Paths] AS [pp] WITH(NOLOCK) ON [pp].[PK_Paths] = [na].[FK_Paths__Process]
		
WHERE
	na.FirstConnectionUTC >= DATEADD(DAY, -1, GETUTCDATE()) 		-- Time
	AND na.FirstConnectionUTC <= GETUTCDATE()						-- Filter
	

	AND pn.FileName IN ('svchost.exe') --,'winword.exe','excel.exe')
	AND na.port NOT IN ('123','0')
	AND sfn.filename LIKE '%Floating_code%'
	AND dom.domain NOT LIKE '%.microsoft.com'
	AND dom.domain NOT LIKE 'microsoft.com'
	AND dom.domain NOT LIKE '%.windowsupdate.com'
	AND dom.domain NOT LIKE '%.ntp.org'
	AND dom.domain NOT LIKE '%.comodoca.com'
	AND dom.domain NOT LIKE '%.windows.com'
	AND dom.domain NOT LIKE '%.msftncsi.com'
	AND dom.domain NOT LIKE '%.usertrust.com'
	AND dom.domain NOT LIKE '%.in.us'
	AND na.ip NOT LIKE '149.165.180.%'
	AND [na].[IP] NOT LIKE '172.1[6-9].%'
	AND [na].[IP] NOT LIKE '172.2[0-9].%'
	AND [na].[IP] NOT LIKE '172.3[0-1].%'
	AND [na].[IP] NOT LIKE '10.%'
	AND [na].[IP] NOT LIKE '192.168%'
	AND [na].[IP] NOT LIKE '127.0.0.1'
	ORDER BY na.FirstConnectionUTC DESC