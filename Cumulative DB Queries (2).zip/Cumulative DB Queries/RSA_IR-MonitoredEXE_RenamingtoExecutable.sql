SELECT  mn.MachineName, se.EventUTCTime, sfn.Filename, se.FileName_Target, se.Path_Target, se.LaunchArguments_Target, sla.LaunchArguments

FROM
	[dbo].[WinTrackingEvents_P0] AS [se] WITH(NOLOCK)
	--[dbo].[WinTrackingEvents_P1] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
	INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [se].[FK_Machines]
	INNER JOIN [dbo].[LaunchArguments] AS [sla] WITH(NOLOCK) ON [sla].[PK_LaunchArguments] = [se].[FK_LaunchArguments__SourceCommandLine]

WHERE 
	[se].[BehaviorFileRenameToExecutable] = 1
	AND [sfn].FileName IN ('cmd.exe','powershell.exe','wscript.exe','cscript.exe')
	AND NOT se.Path_Target LIKE '%\product\%'
	AND NOT se.Path_Target LIKE '%\avamar\%'
	AND NOT se.Path_Target LIKE '%\GoFileRoom\%'
	AND NOT se.Path_Target LIKE '%\Amazon\WorkSpacesConfig\%'
	AND NOT se.Path_Target LIKE '%\Windows\assembly\temp\%'
	AND NOT se.Path_Target LIKE '%\OffScrub_%'
	AND NOT se.FileName_Target = 'HPSSFUpdater.exe'
	AND NOT se.FileName_Target = 'EMN%.dll'