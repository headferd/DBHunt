
SELECT se.EventUTCTime, FileUTCTimeCreated, FilenameUTCTimeCreated

FROM
	[dbo].[WinTrackingEventsCache] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])


WHERE
	[se].[BehaviorProcessCreateProcess] = 1	
	--AND [sfn].[FileName] = 'msiexec.exe'				-- Source Filename
	AND se.FileName_Target = 'vssadmin.exe'				-- Source Filename
	AND se.LaunchArguments_Target LIKE '%delete%'
	
	



