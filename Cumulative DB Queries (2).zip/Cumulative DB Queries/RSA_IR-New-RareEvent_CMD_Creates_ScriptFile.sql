--===== RSA_IR-New-RareEvent_CMD_Creates_ScriptFile ========--

SELECT DISTINCT
	[smp].[FK_Machines] AS [FK_Machines],
	[smp].[PK_MachineModulePaths] AS [FK_MachineModulePaths],
	[sse].[RowSipHash] AS [FK_mocSentinelEvents]
FROM
	[dbo].[WinTrackingEventsCache] AS [sse] WITH(NOLOCK) 
	INNER JOIN [dbo].[MachineModulePaths] AS [smp] WITH(NOLOCK) ON ([smp].[PK_MachineModulePaths] = [sse].[FK_MachineModulePaths])
	INNER JOIN [dbo].[Modules] AS [mo] WITH(NOLOCK) ON ([mo].[PK_Modules] = [smp].[FK_Modules])
	INNER JOIN [dbo].[WinTrackingEventsCache] AS [tse] WITH(NOLOCK) ON ([tse].[HashSHA256_Target] = [mo].[HashSHA256] AND [tse].[FK_Machines] = [smp].[FK_Machines])
	INNER JOIN [dbo].[MachineModulePaths] AS [tmp] WITH(NOLOCK) ON ([tmp].[PK_MachineModulePaths] = [tse].[FK_MachineModulePaths])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [tmp].[FK_FileNames])
	--INNER JOIN [dbo].[LaunchArguments] AS [sla] WITH(NOLOCK) ON [sla].[PK_LaunchArguments] = [sse].[FK_LaunchArguments__SourceCommandLine]
WHERE
	[smp].[FK_Modules] != -1 AND
	[tse].[BehaviorFileWriteExecutable] = 1
	AND sfn.FileName = 'cmd.exe' 
	AND (
		sse.FileName_Target LIKE '%.vbs' OR
		sse.FileName_Target LIKE '%.vbe' OR
		sse.FileName_Target LIKE '%.wsh' OR
		sse.FileName_Target LIKE '%.wsf' OR
		sse.FileName_Target LIKE '%.vb' OR
		sse.FileName_Target LIKE '%.cmd' OR
		sse.FileName_Target LIKE '%.bat'
		)
	AND sse.FileName_Target NOT IN ('Sleep2Seconds.vbs', 'spiceworks_upload.vbs','CopyGISDatabase.bat','execjavatemp.bat','deinstall_startup.bat')
	AND sse.Path_Target NOT LIKE '%\Progra%'
	AND sse.Path_Target NOT LIKE '%\scripts\%'
	AND sse.Path_Target NOT LIKE '%\IBM_LA%'

	AND [smp].[MarkedAsDeleted] = 0 -- Testing MarkedAsDeleted on MP instead of SE for Events
OPTION (RECOMPILE);