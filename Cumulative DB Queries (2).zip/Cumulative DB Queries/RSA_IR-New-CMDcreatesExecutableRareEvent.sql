--===== RSA_IR-New-CMDcreatesExecutableRareEvent ========--


SELECT DISTINCT
	[smp].[FK_Machines] AS [FK_Machines],
	[smp].[PK_MachineModulePaths] AS [FK_MachineModulePaths],
	[sse].[RowSipHash] AS [FK_mocSentinelEvents]
FROM
	[dbo].[WinTrackingEventsCache] AS [sse] WITH(NOLOCK) 
	INNER JOIN [dbo].[MachineModulePaths] AS [smp] WITH(NOLOCK) ON ([smp].[PK_MachineModulePaths] = [sse].[FK_MachineModulePaths])
	INNER JOIN [dbo].[Modules] AS [mo] WITH(NOLOCK) ON ([mo].[PK_Modules] = [smp].[FK_Modules])
	INNER JOIN [dbo].[WinTrackingEventsCache] AS [tse] WITH(NOLOCK) ON ([tse].[HashSHA256_Target] = [mo].[HashSHA256] AND [tse].[FK_Machines] = [smp].[FK_Machines])
	INNER JOIN [dbo].[MachineModulePaths] AS [tmp] WITH(NOLOCK) ON ([tmp].[PK_MachineModulePaths] = [tse].[FK_MachineModulePaths])
	INNER JOIN [dbo].[FileNames] AS [tfn] WITH(NOLOCK) ON ([tfn].[PK_FileNames] = [tmp].[FK_FileNames])
	--INNER JOIN [dbo].[LaunchArguments] AS [sla] WITH(NOLOCK) ON [sla].[PK_LaunchArguments] = [sse].[FK_LaunchArguments__SourceCommandLine]
WHERE
	[smp].[FK_Modules] != -1 AND
	
	[tse].[BehaviorFileWriteExecutable] = 1
	AND [tfn].FileName = 'cmd.exe'
	AND NOT sse.FileName_Target IN ('adobeconnectaddin.exe','VPNDriveMapping.bat','sdk manager.exe')
	AND sse.Path_Target NOT LIKE '%WinmdWorkingFolder\%'
	AND sse.Path_Target NOT LIKE '%\bin\%'
	AND sse.Path_Target NOT LIKE '%\Spiceworks\%'
	AND sse.Path_Target NOT LIKE '%\Program Files%'
	AND sse.Path_Target NOT LIKE '%\fssa_qa_testing\%'

	AND [smp].[MarkedAsDeleted] = 0 -- Testing MarkedAsDeleted on MP instead of SE for Events
OPTION (RECOMPILE);