SELECT  mn.MachineName, se.EventUTCTime, sfn.Filename, se.FileName_Target, se.Path_Target, se.LaunchArguments_Target, sla.LaunchArguments

FROM
	[dbo].[WinTrackingEvents_P0] AS [se] WITH(NOLOCK)
	--[dbo].[WinTrackingEvents_P1] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
	INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [se].[FK_Machines]
	INNER JOIN [dbo].[LaunchArguments] AS [sla] WITH(NOLOCK) ON [sla].[PK_LaunchArguments] = [se].[FK_LaunchArguments__SourceCommandLine]

WHERE 
	[se].[BehaviorProcessCreateProcess] = 1
	AND [se].[LaunchArguments_Target] LIKE '%127.0.0.1:%'
	AND NOT se.FileName_Target LIKE 'vnc%.exe'
	AND NOT se.FileName_Target IN ('CuraEngine.exe','nunit-agent.exe','pinentry.exe','DriverSupport.exe','mongodump.exe','git.exe')
	AND NOT sfn.FileName IN ('java.exe','dvbackrest.exe','git.exe','BvSsh.exe')
	AND se.Path_Target NOT LIKE '%\zoc_\'
	AND [se].[LaunchArguments_Target] NOT LIKE '%http%://127%'
	
	ORDER BY se.EventUTCTime DESC