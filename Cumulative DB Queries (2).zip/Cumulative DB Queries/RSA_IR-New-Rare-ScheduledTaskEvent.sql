--===== RSA_IR-New-Rare-ScheduledTaskEvent ========--

--DB QUERY 

SELECT  mn.MachineName, se.EventUTCTime, sfn.Filename, se.FileName_Target, se.Path_Target, se.LaunchArguments_Target, sla.LaunchArguments

FROM
	[dbo].[WinTrackingEvents_P0] AS [se] WITH(NOLOCK)
	--[dbo].[WinTrackingEvents_P1] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
	INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [se].[FK_Machines]
	INNER JOIN [dbo].[LaunchArguments] AS [sla] WITH(NOLOCK) ON [sla].[PK_LaunchArguments] = [se].[FK_LaunchArguments__SourceCommandLine]

WHERE 
	[se].[BehaviorProcessCreateProcess] = 1  
	 AND se.FileName_Target = 'schtasks.exe'
	 AND sfn.FileName NOT IN ('OfficeClicktoRun.exe', 'wsqmcons.exe','integrator.exe', 'msiexec.exe', 'Teamviewer_.exe', 'Maxthon.exe',
							'DellClientSystemUpdate.exe','mfesetup.exe','pcdrcui.exe','drvinst.exe','UIU64a.exe','appupdater.exe')
	 AND se.LaunchArguments_Target LIKE '%/create%/tn%'
	 AND NOT se.LaunchArguments_Target LIKE '%2Pint Software%'
	 AND NOT se.LaunchArguments_Target LIKE '%\Program Files%'
	 AND NOT se.LaunchArguments_Target LIKE '%WsqmUploaderTask%'
	 AND NOT se.LaunchArguments_Target LIKE '%\support\%'
	 AND NOT se.LaunchArguments_Target LIKE '%\TeamViewer\%'
	 AND NOT se.LaunchArguments_Target LIKE '%Amazon Music Helper" /xml%'
	
	ORDER BY se.EventUTCTime DESC



/*
-- IIOC QUERY
SELECT DISTINCT
	[mp].[FK_Machines] AS [FK_Machines],
	[mp].[PK_MachineModulePaths] AS [FK_MachineModulePaths],
	[se].[PK_WinTrackingEvents] AS [FK_mocSentinelEvents]

FROM
	[dbo].[WinTrackingEventsCache] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
	
WHERE 
	[se].[BehaviorProcessCreateProcess] = 1  
	 AND se.FileName_Target = 'schtasks.exe'
	 AND sfn.FileName NOT IN ('OfficeClicktoRun.exe', 'wsqmcons.exe','integrator.exe', 'msiexec.exe', 'Teamviewer_.exe', 'Maxthon.exe',
							'DellClientSystemUpdate.exe','mfesetup.exe','pcdrcui.exe','drvinst.exe','UIU64a.exe','appupdater.exe')
	 AND se.LaunchArguments_Target LIKE '%/create%/tn%'
	 AND NOT se.LaunchArguments_Target LIKE '%2Pint Software%'
	 AND NOT se.LaunchArguments_Target LIKE '%\Program Files%'
	 AND NOT se.LaunchArguments_Target LIKE '%WsqmUploaderTask%'
	 AND NOT se.LaunchArguments_Target LIKE '%\support\%'
	 AND NOT se.LaunchArguments_Target LIKE '%\TeamViewer\%'
	 AND NOT se.LaunchArguments_Target LIKE '%Amazon Music Helper" /xml%'

	 */