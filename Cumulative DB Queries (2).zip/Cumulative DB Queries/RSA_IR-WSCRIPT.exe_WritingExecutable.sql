--===== RSA_IR-WSCRIPT.exe_WritingExecutable ========--

--/* DB QUERY 

SELECT  mn.MachineName, se.EventUTCTime, sfn.Filename, se.FileName_Target, se.Path_Target, se.LaunchArguments_Target, sla.LaunchArguments

FROM
	[dbo].[WinTrackingEvents_P0] AS [se] WITH(NOLOCK)
	--[dbo].[WinTrackingEvents_P1] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
	INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [se].[FK_Machines]
	INNER JOIN [dbo].[LaunchArguments] AS [sla] WITH(NOLOCK) ON [sla].[PK_LaunchArguments] = [se].[FK_LaunchArguments__SourceCommandLine]

WHERE 
	[se].[BehaviorFileWriteExecutable] = 1
	AND [sfn].FileName IN ('wscript.exe')
	AND se.FileName_Target NOT IN ('robocopy.exe','BackupUserData.vbs','mpam-fe.exe')
	AND se.Path_Target NOT LIKE 'c:\scripts\backup_uti%'
	AND se.Path_Target NOT LIKE 'd:\scep_definition_exes%'

--*/


/* IIOC QUERY
SELECT DISTINCT
	[mp].[FK_Machines] AS [FK_Machines],
	[mp].[PK_MachineModulePaths] AS [FK_MachineModulePaths]

FROM
	[dbo].[WinTrackingEventsCache] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
	
WHERE 
	[se].[BehaviorFileWriteExecutable] = 1
	AND [sfn].FileName IN ('wscript.exe')
	AND se.FileName_Target NOT IN ('robocopy.exe', 'BackupUserData.vbs','mpam-fe.exe')
	AND se.Path_Target NOT LIKE 'c:\scripts\backup_uti%'
	AND se.Path_Target NOT LIKE 'd:\scep_definition_exes%'
*/